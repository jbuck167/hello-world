import React, { Component } from "react";
 
class Home extends Component {
    render() {
      return (
        <div>
          <h2>Home Page</h2>
          <p>The Authors are glad you are here!
          </p>
        </div>
      );
    }
  }
   
  export default Home;