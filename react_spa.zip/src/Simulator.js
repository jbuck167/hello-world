import React, { Component } from "react";
import "./Simulator.css";
 
// Import React Table
import ReactTable from "react-table";
import "react-table/react-table.css";

class Toggle extends React.Component {
    constructor(props) {
      super(props);
      this.state = {isToggleOn: true};
  
      // This binding is necessary to make `this` work in the callback
      this.handleClick = this.handleClick.bind(this);
    }
  
    handleClick() {
      this.setState(prevState => ({
        isToggleOn: !prevState.isToggleOn
      }));
    }
  
    render() {
      return (
        <button onClick={this.handleClick}>
          {this.state.isToggleOn ? 'ON' : 'OFF'}
        </button>
      );
    }
  }

class EventTable extends Component {
    render() {
      return (
        <div class="">
          <ReactTable
            data={data}
            columns={[
            {
              Header: "Name",
              columns: [
                {
                  Header: "First Name",
                  accessor: "firstName",
                  maxWidth: 100
                },
                {
                  Header: "Last Name",
                  id: "lastName",
                  accessor: d => d.lastName,
                  maxWidth: 100
                }
              ]
            },
            {
              Header: "Info",
              columns: [
                {
                  Header: "Age",
                  accessor: "age",
                  minWidth: 25,
                  maxWidth: 100
                }
              ]
            }
          ]}
          defaultPageSize={20}
          style={{
            height: "400px" // This will force the table body to overflow and scroll, since there is not enough room
          }}
          className="-striped -highlight"
        />
      </div>
      );
    }
  }

  var data = [
    {firstName: 1, lastName: 'Gob', age: '2'},
    {firstName: 2, lastName: 'Buster', age: '5'},
    {firstName: 3, lastName: 'George Michael', age: '4'}
  ];

class Simulator extends Component {
  render() {
    return (
        <div>
<div class="container">
   <div class="column column-one">
        Semaphore Queues: <Toggle />
   </div>
   {/* <div class="column column-two"></div>
   <div class="column column-three">Column three</div>
   <div class="column column-four"></div>
   <div class="column column-five">Column five</div> */}
</div>

        <div class="container">
            <div class="column sim-column-one">
              <div class="ex2">
                <h2><center>Incoming Event Queue</center></h2>
                <EventTable data={data}/>
              </div>
              <br/>
              <div class="ex2">
                <h2><center>New Job Queue</center></h2>
                <EventTable data={data}/>
              </div>
            </div>
            <div class="column sim-column-two"></div>
            <div class="column sim-column-three">
            
            </div>
            <div class="column sim-column-four"></div>
            <div class="column sim-column-five">
            
            </div>
        </div>
        </div>
    );
  }
}
 
export default Simulator;